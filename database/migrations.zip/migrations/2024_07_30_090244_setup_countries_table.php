<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SetupCountriesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		// Creates the users table
		Schema::create('countries', function (Blueprint $table)
		{
		    $table->id();
			$table->string('name', 255)->nullable();
			$table->string('currency', 255)->nullable();
			$table->string('currency_symbol', 3)->nullable();
			$table->string('iso_3166_2', 2)->nullable();
			$table->string('iso_3166_3', 3)->nullable();
			$table->string('calling_code', 3)->nullable();
			$table->string('flag')->nullable();
            $table->string('currency_code', 255)->nullable();
		});

		Schema::create('country_states', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
			$table->foreignId('country_id')->nullable()->constrained('countrie')->onDelete('cascade');
            $table->timestamps();
        });
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('countries');
        Schema::dropIfExists('country_states');
	}

}
